from itertools import chain, combinations
import numpy as np
import pandas as pd

from rpy2 import robjects
from rpy2.robjects.packages import importr
from rpy2.robjects import vectors

base = importr("base")
bnlearn = importr("bnlearn")
grain = importr("gRain")


def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


if __name__ == "__main__":
    # Read Asia from BIF.
    b = bnlearn.read_bif("asia_aligned.bif")
    # Get the vertex set.
    v = set(sorted(bnlearn.nodes(b)))
    # Convert to gRain model.
    b = bnlearn.as_grain(b)

    # Initialize data serialization.
    out = "vec![\n"
    # Compute marginal and joint queries.
    for z in powerset(v):
        if len(z) > 0:
            z = sorted(z)
            # Temporary disable ndarray conversion to get names.
            with robjects.conversion.localconverter(robjects.default_converter):
                # Execute queries.
                q = grain.querygrain(b, nodes=vectors.StrVector(z), type="joint")
                # Get query axes order relative to Z.
                axes = list(base.dimnames(q).names)
                axes = [axes.index(i) for i in z]
            # Align query axes to Z.
            q = np.transpose(q, axes)
            # Export results.
            if len(z) == 1:
                out += f"\t(\"marginal\", vec!{list(z)}, vec!{list(q.shape)}, vec!{list(q.flatten())}),\n"
            else:
                out += f"\t(\"joint\", vec!{list(z)}, vec!{list(q.shape)}, vec!{list(q.flatten())}),\n"
    # Compute conditional queris.
    for x in v:
        for z in powerset(v - {x}):
            if len(z) > 0:
                z = [x] + sorted(z)
                # Temporary disable ndarray conversion to get names.
                with robjects.conversion.localconverter(robjects.default_converter):
                    # Execute queries.
                    q = grain.querygrain(b, nodes=vectors.StrVector(z), type="conditional")
                    # Get query axes order relative to Z.
                    axes = list(base.dimnames(q).names)
                    axes = [axes.index(i) for i in z]
                # Align query axes to Z.
                q = np.transpose(q, axes)
                # Export results.
                out += f"\t(\"conditional\", vec!{list(z)}, vec!{list(q.shape)}, vec!{list(q.flatten())}),\n"
    # Conclude data serialization.
    out += "]"

    # Replace \' with \".
    out = out.replace("\'", "\"")
    # Replace "nan" with "f64::NAN".
    out = out.replace("nan", "f64::NAN")

    # Write serialized data to file.
    with open("./discrete.txt", "w") as file:
        file.write(out)
