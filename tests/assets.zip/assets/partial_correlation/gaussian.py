import pandas as pd
import pingouin as pg

from itertools import chain, combinations


def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))

if __name__ == "__main__":
    # Read data from file.
    df = pd.read_csv("../ecoli70.csv")
    # Sort columns.
    cols = sorted(df.columns)
    df = df[cols]

    # NOTE: Limit the number of variables to 8.
    df = df.iloc[:, :8]

    # Initialize data serialization.
    out = "let data = vec![\n"

    # For each pair of columns.
    for (x, y) in combinations(df.columns, 2):
        # Get the rest of the columns.
        w = list(sorted(set(df.columns) - set([x, y])))
        # For each column subset.
        for z in powerset(w):
            # Cast to list.
            z = list(z)
            # Compute the partial correlation.
            r = df.partial_corr(x = x, y = y, covar = z)
            r = float(r.loc["pearson", "r"])
            # Serialize (X, Z, C).
            z = "[" + ", ".join([f"\"{i}\"" for i in z]) + "]"
            out += f"(\"{x}\", \"{y}\", vec!{z}, {r}),\n"

    # End data serialization.
    out += "];\n"

    # Write serialized data to file.
    with open("./gaussian.txt", "w") as file:
        file.write(out)

