import numpy as np
import pandas as pd

from itertools import chain, combinations, product


def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


if __name__ == "__main__":
    # Read data from file.
    df = pd.read_csv("./asia.csv", dtype="category")
    # Sort columns.
    df = df[sorted(df.columns)]

    # Initialize data serialization.
    out = "let data = vec![\n"

    # For each column.
    for x in df.columns:
        # Get the rest of the columns.
        z = sorted(set(df.columns) - set([x]))
        # For each column subset.
        for z in powerset(z):
            # Cast to list.
            z = list(z)
            # Filter empty sets.
            if len(z) > 0:
                # Get the series.
                s_x = [df[x]]
                s_z = [df[i] for i in z]
                # Compute the crosstab.
                c = pd.crosstab(s_z, s_x)
                # Account for missing configurations.
                if len(z) > 1:
                    index = list(product(*[np.unique(i) for i in s_z]))
                    index = pd.MultiIndex.from_tuples(index)
                    c = c.reindex(index, axis=0).fillna(0)
                # Cast to integers.
                c = c.to_numpy().astype(int)
                # Serialize (X, Z, C)
                z = "[" + ", ".join([f"\"{i}\"" for i in z]) + "]"
                c = np.array2string(c, separator=",")
                out += f"(\"{x}\", vec!{z}, array!{c}),\n"

    # End data serialization.
    out += "];\n"

    # Write serialized data to file.
    with open("./conditional_count_matrix.txt", "w") as file:
        file.write(out)
