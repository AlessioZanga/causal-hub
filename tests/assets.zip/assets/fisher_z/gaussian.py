import numpy as np
import pandas as pd

from rpy2.robjects.packages import importr
from rpy2.robjects import pandas2ri, vectors
pandas2ri.activate()

bnlearn = importr("bnlearn")

from itertools import chain, combinations


def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


if __name__ == "__main__":
    # Read data from file.
    df = pd.read_csv("../ecoli70.csv")
    # Sort columns.
    cols = sorted(df.columns)
    df = df[cols]

    # NOTE: Limit the number of variables to 8.
    df = df.iloc[:, :8]

    # Initialize data serialization.
    out = "let data = vec![\n"

    # For each column.
    for (x, y) in combinations(df.columns, 2):
        # Get the rest of the columns.
        w = list(sorted(set(df.columns) - set([x, y])))
        # For each column subset.
        for z in powerset(w):
            # Cast to list.
            z = vectors.StrVector(list(z))
            # Compute the Fishser-z test.
            t = bnlearn.ci_test(x, y, z, data = df, test = "zf")
            (dof, stat, pval) = (t[6], t[0], t[3])
            t = (int(dof), float(stat), float(pval))
            # Serialize (X, Z, C).
            z = "[" + ", ".join([f"\"{i}\"" for i in z]) + "]"
            out += f"(\"{x}\", \"{y}\", vec!{z}, {t}),\n"

    # End data serialization.
    out += "];\n"

    # Write serialized data to file.
    with open("./gaussian.txt", "w") as file:
        file.write(out)
