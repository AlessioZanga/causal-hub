import numpy as np
import pandas as pd

from rpy2.robjects.packages import importr
from rpy2.robjects import pandas2ri
pandas2ri.activate()

bnlearn = importr("bnlearn")

from itertools import chain, combinations


def powerset(iterable):
    s = list(iterable)
    return chain.from_iterable(combinations(s, r) for r in range(len(s)+1))


if __name__ == "__main__":
    # Read data from file.
    df = pd.read_csv("./asia.csv", dtype="category")
    # Sort columns.
    cols = sorted(df.columns)
    df = df[cols]

    # Initialize data serialization.
    out = "let data = vec![\n"

    # For each column.
    for x in df.columns:
        # Get the rest of the columns.
        w = list(sorted(set(df.columns) - set([x])))
        # For each column subset.
        for z in powerset(w):
            # Cast to list.
            z = list(z)
            # Compute the log-likelihood.
            if len(z) > 0:
                s = f"[{x}|{':'.join(z)}]" + "".join([f"[{i}]" for i in w])
            else:
                s = f"[{x}]" + "".join([f"[{i}]" for i in w])
            s = bnlearn.model2network(s)
            s = bnlearn.score(s, df, type = "loglik", **{"by.node": True})
            s = s[cols.index(x)]
            # Serialize (X, Z, C).
            z = "[" + ", ".join([f"\"{i}\"" for i in z]) + "]"
            out += f"(\"{x}\", vec!{z}, {s}),\n"

    # End data serialization.
    out += "];\n"

    # Write serialized data to file.
    with open("./log_likelihood.txt", "w") as file:
        file.write(out)
